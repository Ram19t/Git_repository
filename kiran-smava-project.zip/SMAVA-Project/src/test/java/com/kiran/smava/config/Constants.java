package com.kiran.smava.config;

public class Constants {
public static final String url = "https://www.smava.de/";

public static final String chrome = "chrome";

public static final String firefoxBrowser = "firefox";

public static final String Homepagetitle ="SMAVA - Das Online-Vergleichsportal f�r Kredite | SMAVA";

public static final String userDir = "D:\\New folder\\selenium_practice\\SMAVA-Project";

}
